package com.MedRef.MedApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MedAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
